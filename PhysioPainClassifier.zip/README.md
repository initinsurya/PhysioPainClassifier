# Pacakges

sys
csv
numpy as np
sklearn.metrics  
sklearn.ensemble  
sklearn.model_selection
os
matplotlib.pyplot

# Run Project2.py file

Command line earguments format "python .\Project2.py dia ./Project2Data.csv"

# Code

The project code is in the file - Project2.py
